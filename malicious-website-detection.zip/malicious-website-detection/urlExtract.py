#URL extraction code
#only focus on the first two categories of features
#more efforts are needed

__author__ = "ketian"


import re
#urlib2 is only used for python2
#use urllib for python 3
import urllib2
from urlparse import urlparse

opener = urllib2.build_opener()
opener.addheaders = [('User-agent', 'Mozilla/5.0')]

DEFAULT_VALUE = -1

# return the count of sensitive words
# @input: tokenized words
# @output: the count of sensitive/security tokens
def Security_sensitive(tokens_words):

    sec_sen_words=['confirm', 'account', 'banking', 'secure', 'ebayisapi', 'webscr', 'login', 'signin']
    cnt=0
    for ele in sec_sen_words:
        if(ele in tokens_words):
            cnt+=1
    return cnt


#a class to extract to extract features
#
class featureUrl():

    Feature = {}
    url = ""

    def __init__(self,urlString):
        self.url = urlString
        self.basic_feature()
        self.statistic_feature()
        #self.web_content_features()

    def basic_feature(self):
        self.Feature['Length_of_url']=len(self.url)
        self.Feature['No_of_dots_url']=self.url.count('.')


    def statistic_feature(self):
        tokens_words=re.split('\W+',self.url)
        #print (tokens_words)
        self.Feature['sec_sen_word_cnt'] = Security_sensitive(tokens_words)


    def host_features(self):
        obj=urlparse(self.url)
        host=obj.netloc
        path=obj.path
        print (host)
        print (path)


    #TODO need to implement more
    def web_content_features(self):

        try:
            f = opener.open(self.url)
            source_code = str(f.read())
            self.Feature['src_html_cnt']=source_code.count('<html')
            self.Feature['src_iframe_cnt']=source_code.count('<iframe')
            self.Feature['src_script_cnt']=source_code.count('<script')
            #print (source_code)

        except:
            print ("opps! error happens")
            self.Feature['src_html_cnt']= -1
            self.Feature['src_iframe_cnt']= -1
            self.Feature['src_script_cnt']= -1


    def featureVectorGenerate(self):
        ans = []
        for i in sorted(self.Feature):
            ans.append(self.Feature[i])

        #print (ans)
        return ans

    def printFeature(self):
        for i in self.Feature:
            print ("Feature {} -> Value {}".format(i, self.Feature[i]))



#test the url feature extraction
if __name__=="__main__":
    url1 = 'http://microsoftonline.com'
    url1 = 'http://leamachado.com'
    fs = featureUrl(url1)
    fs.printFeature()
    fs.featureVectorGenerate()