## create and edit by ketian@2017

__author__ = "ketian"

import sys
import os

"""
I use beautiful soup to
"""
from bs4 import BeautifulSoup
import re
#import urllib2

#url is a file diretory
def readHtmlFromFile(url):
    soup = BeautifulSoup(open(url),"html.parser")
    ss = soup.findAll('script')
    ss = soup.findAll('iframe')
    print (id(ss))
    print (ss)

def test():
    url = "sample_mali_rig.html"
    readHtmlFromFile(url)
    return

if __name__=="__main__":
    print ("hello world")
    test()