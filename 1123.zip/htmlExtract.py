#!/usr/bin/env python
# -*- coding: utf-8 -*-

## create and edit by ketian@2017

__author__ = "ketian"

import sys
import os

"""
I use beautiful soup to do the HTML parse
The main object used here is the 
"""
from bs4 import BeautifulSoup
import re
from urlFeature import featureUrl
#import urllib2

def readString(name):
    with open(name, "r") as myfile:
        data = myfile.readlines()
        print len(data)
    pass

#url is a file diretory
def readHtmlFromFile(url):
    soup = BeautifulSoup(open(url),"html.parser")
    ifames = soup.findAll("iframe")
    count = 0
    for iframe in ifames:
        print (count)
        count += 1
        print type(iframe)
        iffInstance = iframeFeature(iframe)


def test():
    url = "gist1.html"
    url1 = "rig-gist1.txt"
    url = "data.html"
    urltest = "test.txt"
    readHtmlFromFile(urltest)
    return


"""
This is the object to tract features from the iframe
currently, I only consider each iframe independently.
Th goal: for each iframe I make a list 
"""
class iframeFeature():
    iframe = None
    iframeFeature = {}
    src = None

    def __init__(self, ifrmae):
        self.iframe = ifrmae
        self.attr_analysis()
        pass

    #the type is <type 'unicode'>
    def attr_analysis(self):
        keyAt = "src"
        if keyAt in self.iframe.attrs:
            print ("Src attribute is in the iframe")
            self.src = self.iframe.get('src')
            print ("The src is:\n" + str(self.src))
            self.getSRC()
        for item in self.iframe.attrs:
            print (item)

    def getSRC(self):
        self.src = self.iframe.get("src")
        urlfeatureinstance = featureUrl(self.src)
        urlfeatureinstance.printFeature()


    def print_info(self):
        print ("The type of the iframe is:")
        print (type(self.iframe))

        print ("The id of the iframe is:")
        print (id(self.iframe))

        print ("The features of the iframe is:")


if __name__=="__main__":
    print ("hello world")
    test()
    #readString("rig-gist1.txt")