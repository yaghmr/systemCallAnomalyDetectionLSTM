#!/usr/bin/env python
# -*- coding: utf-8 -*-

#URL extraction code
# #only focus on the first two categories of features
#more efforts are needed

__author__ = "ketian"

import re
#urlib2 is only used for python2
#use urllib for python 3
import urllib2
from urlparse import urlparse

#library to get subdomain
import tldextract

opener = urllib2.build_opener()
opener.addheaders = [('User-agent', 'Mozilla/5.0')]

DEFAULT_VALUE = -1

# return the count of sensitive words
# @input: tokenized words
# @output: the count of sensitive/security tokens
def Security_sensitive(tokens_words):

    sec_sen_words=['confirm', 'account', 'banking', 'secure', 'ebayisapi', 'webscr', 'login', 'signin']
    cnt=0
    for ele in sec_sen_words:
        if(ele in tokens_words):
            cnt+=1
    return cnt

"""
This util includes the string functions
for randomness, entropy,
whether a word is in a dictionary and the meaning of a url
"""
class Tool_Ke_URL():

    #extract subdomain, domain and suffix
    #we remove the www
    @staticmethod
    def subdomain(url):
        #cleean url
        ex = tldextract.extract(url)
        subdomain = ex.subdomain
        #the www is not a subdomain
        if subdomain == "www":
            subdomain = ""
        if subdomain.startswith("www."):
            subdomain = subdomain[4:]
        domain = ex.domain
        suffix = ex.suffix
        return (subdomain, domain, suffix)


    @staticmethod
    def queryInURL(url):
        pass

"""
a class to extract to extract features
A list of features:
- protocol
- resource name
"""

class featureUrl():

    Feature = {}
    url = ""
    subdomain = ""
    domain = ""
    suffix = ""

    def __init__(self,urlString):
        self.url = urlString
        #self.basic_feature()
        #self.statistic_feature()
        #self.subdomain_feature()
        #self.web_content_features()

    def basic_feature(self):
        self.Feature['Length_of_url']=len(self.url)
        self.Feature['No_of_dots_url']=self.url.count('.')

    # this feature is used to analyze the sub-domain features
    # an example of the sub-domain is: menu.pizzashopping.com
    # the subdomain name menu can be compromised.
    def subdomain_feature(self):
        ex = tldextract.extract(self.url)
        self.subdomain =  ex.subdomain
        self.domain = ex.domain
        self.suffix = ex.suffix
        print (ex)


    def statistic_feature(self):
        tokens_words=re.split('\W+',self.url)
        print (tokens_words)
        self.Feature['security_sen_word_cnt'] = Security_sensitive(tokens_words)


    def host_features(self):
        obj=urlparse(self.url)
        host=obj.netloc
        path=obj.path
        print (host)
        print (path)


    #TODO need to implement more
    #TODO plesase do not run the code indeed, as it will execute the url and get the object
    def web_content_features(self):

        try:
            f = opener.open(self.url)
            source_code = str(f.read())
            self.Feature['src_html_cnt']=source_code.count('<html')
            self.Feature['src_iframe_cnt']=source_code.count('<iframe')
            self.Feature['src_script_cnt']=source_code.count('<script')
            #print (source_code)

        except:
            print ("opps! error happens")
            self.Feature['src_html_cnt']= -1
            self.Feature['src_iframe_cnt']= -1
            self.Feature['src_script_cnt']= -1


    def featureVectorGenerate(self):
        ans = []
        for i in sorted(self.Feature):
            ans.append(self.Feature[i])

        #print (ans)
        return ans

    def printFeature(self):
        for i in self.Feature:
            print ("Feature {} -> Value {}".format(i, self.Feature[i]))




#test the url feature extraction
if __name__=="__main__":
    url1 = 'http://microsoftonline.com'
    url1 = 'http://leamachado.com'
    url = "www.jasonryananimation.com"
    uu = "hdjavporn.com"
    #uu = "k3-mebel.ru"
    uu = "asianinspirations.com.au"
    #uu = "best.BESTTHINGSINLIFERFREE.COM".lower()
    #uu ="https://www.jasonryananimation.com"
    uu = "https://www.blog.google.com/"
    uu = "www.gremoquegua.edu.pe"
    uu = "http://hello.example.com.cn/foo/foo/foo?bar/bar/bar"

    uu = "http://example.com/?br_fl=3020&yus=Amaya.80jo101.406p2i2l3&ct=Amaya&biw=Amaya.128kz73.406b4z6f1&tu" \
         "if=3088&q=wXzQMvXcJwDQDIbGMvrESLtANknQA0KK2Ij2_dqyEoH9eWnihNzUSkrz6B2aC&oq=m2F_fd7LeRVPgvkihaBcwxomox" \
         "eUQ5H9Kivj0fUnRXIgpTR-heFUTp1u9CdUbI"

    print (Tool_Ke_URL.subdomain(uu))
    #fs = featureUrl(uu)
    #fs.subdomain_feature()
    #fs.printFeature()
    #fs.featureVectorGenerate()