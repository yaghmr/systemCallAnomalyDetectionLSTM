# used for data processing
#
#
__author__ = "ketian"


import numpy as np
from urlFeature import *

fname = "data/URL.txt"
storefile = "smalldata.csv"

def read_url_data(fname):
    with open(fname) as f:
        content = f.readlines()
    # you may also want to remove whitespace characters like `\n` at the end of each line
    content = [x.strip() for x in content]

    data = []
    #transform into X,y format
    for line in content:

        if len(line) == 0:
            continue

        tmp = line.split(",")
        if len(tmp) != 2:
            pass
        else:
            url = tmp[0]
            fs = featureUrl(url)
            vector = fs.featureVectorGenerate()
            label = int(tmp[1])
            vector.append(label)
            data.append(list(vector))
            fs = None

    _store_lists(data)
    print ("Done!")

def _store_lists(lists):
    a = np.asarray(lists)
    np.savetxt(storefile, a, delimiter=",")


def _read_lists(filename):
    data = np.genfromtxt(filename, delimiter=',')
    x_len, y_len = data.shape
    print (data.shape)
    X = data[:,  : (y_len-1)]
    y = data[:, y_len-1]
    return X,y

def test():
    #read_url_data(fname)
    fname = storefile
    _read_lists(fname)



test()