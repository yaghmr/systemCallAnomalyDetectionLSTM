__author__ = "ketian"

import csv
import sys
import collections
"""
In this file, I read the csv file and find the particular compromised urls and 
"""
import urlFeature

#global define a N/A
NA = "N/A"
#
# read a csv file and store its elements in a dictionary
#
def csvReadFromFile(filename):

    dic = collections.defaultdict(list)
    head = None
    with open(filename) as csvfile:
        rownum = 0
        readCSV = csv.reader(csvfile, delimiter=',')
        print (readCSV)
        for row in readCSV:
            if rownum == 0:
                head = row #is a list
                for i in range(len(head)):
                    head[i] = head[i].strip() #remove begin and end white space
                print ("The head of the csv file is " + str(head))
                #construct the dic
            else:
                try:
                    for i in range(len(row)):
                        idx = head[i]
                        value = row[i].strip()
                        dic[idx].append(value)
                except:
                    print ("OOPs! the row is broken")
                    print (row)

            rownum += 1

    #test whether the dic is correct
    """
    for i in head:
        print (dic[i][0:2])
    """
    #filter non-rig EK
    rig_ek_string = "Rig EK"
    rig_idx = []
    rig_count = 0
    EKs= dic["EK"]
    for i in range(0,len(EKs),1):
        if EKs[i] == rig_ek_string:
            rig_idx.append(True)
            rig_count += 1
        else:
            rig_idx.append(False)

    print ("The total entries is {}\nThe total rig_count is {}".format(len(EKs),rig_count))
    #test
    #for i in range(len(rig_idx)):
    #    if  not rig_idx[i]:
    #       print (i),
    #        print (dic["Campaign"][i])


    #findAinstance(head, dic, rig_idx)
    #sys.exit("done here")

    compromisedUrls  = [val for val, isrig in zip(dic["Compromised"], rig_idx) if isrig]
    #print (compromisedUrls)
    print ("\nTotal compromised urls {}, unique compromized urls {}".
           format(len(compromisedUrls), len(set(compromisedUrls))))

    #comprolist = list(set(compromisedUrls))
    #compromisedUrlsAnalysis(comprolist)

    EKhostUrls = [val for val, isrig in zip(dic["EK Host"], rig_idx) if isrig]
    # print (compromisedUrls)
    print ("\nTotal EKhostUrls urls {}, unique EKhostUrls urls {}".
           format(len(EKhostUrls), len(set(EKhostUrls))))

    ekHostlist = list(set(EKhostUrls))
    EKHostAnalysis(ekHostlist)

    return (head,dic,rig_idx)

#The head of the csv file is ['Campaign', 'EK', 'Compromised', 'CMS', 'EK Host', 'EK IP', 'Gist', 'Date(JST)']
#
#
#               KE TIAN @ We only analysis EK is Rig EK
#

#A dynamic programming solution for edit distance
def edit_distance(s1, s2):
    m=len(s1)+1
    n=len(s2)+1

    tbl = {}
    for i in range(m): tbl[i,0]=i
    for j in range(n): tbl[0,j]=j
    for i in range(1, m):
        for j in range(1, n):
            cost = 0 if s1[i-1] == s2[j-1] else 1
            tbl[i,j] = min(tbl[i, j-1]+1, tbl[i-1, j]+1, tbl[i-1, j-1]+cost)

    return tbl[i,j]

def getEditdistancefromSamples():
    u1 = "amaz0ns.com"
    u11 = "amazon.com"
    print(edit_distance(u1, u11))
    print(edit_distance("lenovo.com", " lenovo-fun.com"))

def findAinstance(head,dic,rig_idx):
    com = dic["Compromised"]
    ekhost = dic["EK Host"]
    time = dic["Date(JST)"]
    for i in range(len(com)):
        if com[i] == "www.lovlose.com":
            print (com[i],ekhost[i],time[i])

#TODO: Website feature
def compromisedUrlsAnalysis(comprolist):
    assert isinstance(comprolist, list), 'Argument of wrong type of compromised list!'
    hasSubdomain = 0
    total = 0
    suffix_dic = collections.defaultdict(int)
    for url in comprolist:
        if url == NA:
            continue

        (subdomain, domain, suffix) = urlFeature.Tool_Ke_URL.subdomain(url)
        suffix_dic[suffix] += 1

        if subdomain != "":
            print (subdomain,url)
            hasSubdomain += 1

        total += 1
        #print (subdomain, domain, suffix)
    print (hasSubdomain,total)
    print (suffix_dic)
    draw_pie(suffix_dic)


#TODO: Iframe feature
def EKHostAnalysis(EkHostlist):
    assert isinstance(EkHostlist, list), 'Argument of wrong type of ekhost list!'
    hasSubdomain = 0
    total = 0
    suffix_dic = collections.defaultdict(int)
    subdomain_list = []
    for url in EkHostlist:
        url = url.lower()
        if url == NA:
            continue

        (subdomain, domain, suffix) = urlFeature.Tool_Ke_URL.subdomain(url)
        suffix_dic[suffix] += 1

        if subdomain != "":
            #print (subdomain, url)
            subdomain_list.append(subdomain)
            hasSubdomain += 1
        else:
            print (url)

        total += 1
        # print (subdomain, domain, suffix)
    print (hasSubdomain, total)
    subdomain_analysis(subdomain_list)
    #print (suffix_dic)
    #draw_pie(suffix_dic)


################ subdomain features #############
#
# This is used to analyze the distributions of subdomains in the urls
#
#TODO subdomain feature extraction
def subdomain_analysis(subdomain_list):
    assert isinstance(subdomain_list, list), 'Argument of wrong type of subdomain list!'
    length_dic = collections.defaultdict(int)
    hasnumber = 0
    is_english_word = 0
    total = 0
    others = 0

    #more fine grained condition
    has_num_and_english_word = 0
    word_file =  open("wordsEn.txt")
    english_words = set(word.strip().lower() for word in word_file)
    #print ("svv" in english_words)
    #sys.exit("NOT")

    for i in subdomain_list:
        length_dic[len(i)] += 1

        if any(t.isdigit() for t in i):
            hasnumber += 1
        elif i in english_words:
            is_english_word += 1
        else:
            others += 1

        total += 1

    print ("total count:" + str(total))
    print ("containNumber word count:" + str(hasnumber))
    print ("English word count:" + str(is_english_word))
    print ("Others count:" + str(others))
    #draw_pie(length_dic)


################ Fine-grained domain features #############
#
# This is used to analyze the distributions of domains in the urls
#
#TODO domain features extraction
def domain_analysis(domain_list):
    assert isinstance(domain_list, list), 'Argument of wrong type of subdomain list!'
    length_dic = collections.defaultdict(int)

    for i in domain_list:
        t = len(i)
        length_dic[i] += 1

    print ("Domain List length distribution")
    print (length_dic)


################ Draw Graphs #############
import matplotlib.pyplot as plt
import numpy as np
import operator

def draw_pie(any_dict):
    # Pie chart, where the slices will be ordered and plotted counter-clockwise:
    labels =[]
    sizes = []
    keys = sorted(any_dict.items(), key=operator.itemgetter(1))
    #print (keys)
    for key,value in keys:
        labels.append(key)
        sizes.append(value)

    sizes = np.asarray(sizes)
    porcent = 100. * sizes / sum(sizes)
    labels = ['{0} - {1:1.2f} %'.format(i, j) for i, j in zip(labels, porcent)]
    fig1, ax1 = plt.subplots()
    ax1.pie(sizes,  labels=labels, autopct='%1.1f%%',startangle=90)
    ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

    """"
    patches, texts = plt.pie(sizes,shadow=True, startangle=90)

    sort_legend = True
    if sort_legend:
        patches, labels, dummy = zip(*sorted(zip(patches, labels, sizes),
                                             key=lambda x: x[2],
                                             reverse=True))

    plt.legend(patches, labels, loc='left center', bbox_to_anchor=(-0.1, 1.),
               fontsize=8)

    plt.savefig('piechart.png', bbox_inches='tight')
    """
    plt.show()


if __name__=="__main__":
    f = "rig-compromised_toLandingPages_21feb-10apr.csv"
    csvReadFromFile(f)
    #getEditdistancefromSamples()