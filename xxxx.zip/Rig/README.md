# malicious-website-detection
A prototype for malicious website detection


## Results

Size:

858 URLs 

3 feature

Matrix X (858, 3)
label  Y (858,1)

```python
KNN
Accuracy: 0.72 (+/- 0.08)

Naive Bayes
Accuracy: 0.64 (+/- 0.03)

Decision Tree
Accuracy: 0.74 (+/- 0.05)

Random Forest
Accuracy: 0.74 (+/- 0.04)

SVM-rbf 
Accuracy: 0.74 (+/- 0.05)
```
<img src="https://github.com/ririhedou/malicious-website-detection/blob/master/result/roc.png" height="500" width="500">

## Requirements:

sklean

matplotlib

numpy

urllib2

urlparse

