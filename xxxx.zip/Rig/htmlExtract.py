#!/usr/bin/env python
# -*- coding: utf-8 -*-

## create and edit by ketian@2017
__author__ = "ketian"
import sys
import os
import hashlib

"""
I use beautiful soup to do the HTML parse
The main object used here is the 
"""
import bs4
from bs4 import BeautifulSoup
# import re
from urlFeature import featureUrl

# import urllib2

LOGGING = False


# read data from a file
# remove unnecessary white-spaces
def readStringsfromHTML(name):
    data = []
    with open(name, "r") as myfile:
        for line in myfile:
            data.append(line.strip().replace(" ", ""))
            # print (type(data))
    return (data)


def md5(fname, blocksize=4096):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(blocksize), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


# TODO Relative location by line
# TODO Relative Location by element hierarchy
"""
In this location detection:
1) get direct code loaction of an iframe
2) get the element's relative location
"""


def getFeatures_Code_Location(iframe, datastrings):
    features = ['iframe_exact_line_number',
                'iframe_relative_location']

    dicLocation = {}
    for i in features:
        dicLocation[i] = -1

    Doctype = "<!DOCTYPE"
    body = "<body>"
    head = "<head>"

    # what if the src is dynamically located?
    if not iframe.get("src"):
        return dicLocation

    src = str(iframe.get("src"))
    ifm = "iframe"
    found = False

    totallinenumber = len(datastrings)
    linenum, relative = -1, -1.0
    Doctypelinenume = -1
    bodylinenumber = -1
    headlinenumber = -1

    for i in range(0, len(datastrings), 1):
        if datastrings[i].startswith("<!--"):
            continue

        if datastrings[i].startswith(Doctype):
            Doctypelinenume = i + 1

        if datastrings[i].startswith(head):
            headlinenumber = i + 1

        if datastrings[i].startswith(body):
            bodylinenumber = i + 1

        if (ifm in datastrings[i]) and (src in datastrings[i]):
            if found:
                print ("[getCodeLocation] Already found once!")
            else:
                linenum = i + 1
                relative = (i + 1 + 0.0) / len(datastrings)

    dicLocation['iframe_exact_line_number'] = linenum
    dicLocation['iframe_relative_location'] = relative

    # print (dicLocation)
    return dicLocation


def getFeatures_Out_of_Space(iframe, soup):
    # this check whether a iframe is in a relative location
    features = ["iframe_out_of_body",
                "iframe_out_of_html",
                "iframe_out_of_head"
                ]
    out_of_space_dict = {}
    for i in features:
        out_of_space_dict[i] = 1

    # it should be only one!

    body = str("body")
    html = str("html")
    head = str("head")

    if isIframeInTheTag(iframe, soup, body):
        out_of_space_dict["iframe_out_of_body"] = -1

    if isIframeInTheTag(iframe, soup, html):
        out_of_space_dict["iframe_out_of_html"] = -1

    if isIframeInTheTag(iframe, soup, head):
        out_of_space_dict["iframe_out_of_head"] = -1

    # pass
    if LOGGING:
        print (out_of_space_dict)
    return out_of_space_dict


def isIframeInTheTag(iframe, soup, name):
    tags = soup.findAll(name)
    for eachTag in tags:
        tmp = iframe
        while tmp.parent:
            tmp = tmp.parent
            if tmp.name == name:
                return True
    return False


"""
In this hidden detection:
I detect two types of hidden behaviors 
I set three 3 rules.
Type 1: Dimension tricks
(1)<iframe src="hxxp://google-analyz .cn/ count.php?o=1" width=0 height=0 scrolling=no></iframe>

(2)<span style="position:absolute; top:-1160px; width:315px; height:318px;">
<iframe src="https://www.w3schools.com" width="257" height="270"></iframe></span>

Type 2: Invisible styles 
(1)<iframe src="https://www.w3schools.com" width=180 height=141 style="visibility: hidden"></iframe>

(2)<div style="display:none">
<iframe src="https://www.w3schools.com" width=574 height=455 ></iframe>
</div>
"""


def is_float_try(str1):
    try:
        float(str1)
        return True
    except ValueError:
        return False


def is_small_than_threshold(strcheck):
    THRESHOLD = 5.0  # i define it by my self
    if "%" in strcheck:
        strcheck = strcheck.replace("%", "")
    if "px" in strcheck:
        strcheck = strcheck.replace("px", "")

    if is_float_try(strcheck):
        w = float(strcheck)
        if w < THRESHOLD:
            if LOGGING:
                print ("The number {} in the string is very small".format(w))
            return True
        else:
            # print ("The number {} in the string is not small".format(w))
            return False

    return False


def is_a_large_negative_number(strcheck):
    strcheck1 = strcheck.replace(" ", "").lower()
    THRESHOLD = 500.0
    if "%" in strcheck1:
        strcheck1 = strcheck1.replace("%", "")
    if "px" in strcheck1:
        strcheck1 = strcheck1.replace("px", "")

    if is_float_try(strcheck1):
        w = float(strcheck1)
        if w < 0 and abs(w) > THRESHOLD:
            if LOGGING:
                print ("The number {} in the string is a negative with large absolute number".format(w))
            return True
        else:
            # print ("The number {} in the string is not small".format(w))
            return False
    return False


def style_string_to_dic(stylestring):
    stylestring = stylestring.replace(" ", "").lower()
    components = stylestring.split(";")
    dic = {}
    for i in components:
        if (len(i) == 0) or (not ":" in i):
            continue
        key = i.split(":")[0]
        value = i.split(":")[1]
        dic[key] = value
    return (dic)


# TODO Rule 1: width and height is very small
# TODO Rule 2: position-absoulte and top a very negative value
# TODO Rule 3: display:none or visibility:hidden
# dimension trick: width,height is 0 or very small
def Analyze_tag_dic_by_rules(tag_dic):
    assert isinstance(tag_dic, dict), "TAG_Dict must be a dictionary"
    rule1, rule2, rule3 = False, False, False
    wid = "width"
    hei = "height"

    if LOGGING:
        print ("\nThe tag dic is:")
        print (tag_dic)
        print ("\n")
    ###RULE 1
    if wid in tag_dic:
        width = tag_dic[wid]
        if is_small_than_threshold(width):
            rule1 = True
    if hei in tag_dic:
        height = tag_dic[hei]
        if is_small_than_threshold(height):
            rule1 = True

    ####RULE 2:
    pos = "position"
    if pos in tag_dic:
        if str(tag_dic[pos]) == "absolute":
            t = "top"
            if t in tag_dic:
                top = tag_dic[t]
                if LOGGING:
                    print ("XXXX-The rule 2 analysis-XXXXX", top)
                if is_a_large_negative_number(top):
                    rule2 = True
    # RULE 3
    dis = "display"
    vis = "visibility"
    if dis in tag_dic:
        if tag_dic[dis] == "none":
            rule3 = True
    if vis in tag_dic:
        if tag_dic[vis] == "hidden":
            rule3 = True

    if LOGGING:
        if rule1:
            print ("RULE 1 is True")
        if rule2:
            print ("RULE 2 is True")
        if rule3:
            print ("RULE 3 is True")

    return (rule1, rule2, rule3)


def get_all_tag_labels(tag):
    tag_dic = {}

    for i in tag.attrs:
        i = str(i).replace(" ", "").lower()
        if i in tag_dic:
            continue
        else:
            tag_dic[i] = str(tag.get(i)).replace(" ", "").lower()

    # extend the style into sub-elements for HTMLS
    if tag.get("style"):
        style = tag.get("style")
        dic = style_string_to_dic(style)
        for i in dic:
            i = str(i)
            if i in tag_dic:
                continue
            else:
                tag_dic[i] = str(dic[i])

    return (tag_dic)


def getFeatures_iframe_Is_Hidden(iframe):
    assert isinstance(iframe, bs4.element.Tag), 'Argument of wrong type of an iframe object in beautifulSoup!'

    features = ["rule1_dimension_trick",
                "rul2_absolute_top_negative",
                "rule3_visible_none"]

    rules_dic_feature = {}
    # we set the max depth to trace back
    MAX_DEPTH = 2
    count = 0
    tag = iframe
    # which kind of hidden technique it used
    re1, re2, re3 = False, False, False
    while count < MAX_DEPTH:
        if tag.parent:
            tag_dict = get_all_tag_labels(tag)
            # print (tag_dict)
            r1, r2, r3 = Analyze_tag_dic_by_rules(tag_dict)
            # print ("A rule is true")
            re1 = r1 or re1
            re2 = r2 or re2
            re3 = r3 or re3
            tag = tag.parent
        else:
            # print ("No more parent")
            break
        count += 1

    # print (re1,re2,re3)
    if re1:
        rules_dic_feature[features[0]] = 1
    else:
        rules_dic_feature[features[0]] = -1

    if re2:
        rules_dic_feature[features[1]] = 1
    else:
        rules_dic_feature[features[1]] = -1

    if re3:
        rules_dic_feature[features[2]] = 1
    else:
        rules_dic_feature[features[2]] = -1

    # print ("done")
    return rules_dic_feature


def test():
    url = "gist1.html"
    url1 = "rig-gist1.txt"
    url = "data.html"
    urltest = "iframe_sample.html"
    readHtmlFromFile(urltest)
    return


##https://www.w3schools.com/code/tryit.asp?filename=FG53GGIJ196H
"""
This is the object to tract features from the iframe
currently, I only consider each iframe independently.
Th goal: for each iframe I make a list 
"""


# url is a file diretory
def readHtmlFromFile(url):
    print ("MD5 hash value is:")
    print (md5(url))
    datastring = readStringsfromHTML(url)
    soup = BeautifulSoup(open(url), "html.parser")
    ifames = soup.findAll("iframe")
    count = 0
    for iframe in ifames:
        print (count)
        count += 1
        # print (type(iframe))
        print (iframe)
        print (getFeatures_Code_Location(iframe, datastring))
        print (getFeatures_Out_of_Space(iframe, soup))
        print (getFeatures_iframe_Is_Hidden(iframe))


# TODO not implement the clear structured iframe
class IframeFeature():
    iframe = None
    iframeFeatureMap = {}
    src = None

    def __init__(self, ifrmae):
        self.iframe = ifrmae
        pass

    def getLocationFeature(self):
        pass

    # hidden feature
    def getHiddenFeatures(self):
        pass

    def getSRC(self):
        self.src = self.iframe.get("src")
        urlfeatureinstance = featureUrl(self.src)
        urlfeatureinstance.printFeature()

    def print_info(self):
        print ("The type of the iframe is:")
        print (type(self.iframe))

        print ("The id of the iframe is:")
        print (id(self.iframe))

        print ("The features of the iframe is:")


if __name__ == "__main__":
    print ("hello world")
    test()
    # readString("rig-gist1.txt")
